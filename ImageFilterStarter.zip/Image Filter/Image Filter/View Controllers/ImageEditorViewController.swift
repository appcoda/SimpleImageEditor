//
//  ImageEditorViewController.swift
//  Image Filter
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import Cocoa

class ImageEditorViewController: NSViewController {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var imageView: NSImageView!
    
    @IBOutlet weak var colorFilters: NSPopUpButton!
    
    @IBOutlet weak var imageNameLabel: NSTextField!
    
    @IBOutlet weak var imageSizeLabel: NSTextField!
    
    
    
    // MARK: - Properties
    
    var imageEditorViewModel = ImageEditorViewModel()
    
    
    
    
    // MARK: - VC Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Populate the available filters to the colorFilters popup button.
        colorFilters.removeAllItems()
        colorFilters.addItems(withTitles: imageEditorViewModel.availableFilters)
        
        
        // The following closure is called when an image is loaded.
        // In it:
        // - Show the image to the imageView.
        // - Show the image name and size to the respective labels.
        // - Make sure that the shown filter is "none" in the colorFilters popup.
        imageEditorViewModel.imageDidLoadHandler = { [unowned self] (imageData) in
            guard let image = NSImage(data: imageData) else { return }
            self.imageView?.image = image
            self.imageNameLabel.stringValue = self.imageEditorViewModel.imageName ?? ""
            self.imageSizeLabel.stringValue = self.imageEditorViewModel.displayedImageSizeString
            self.colorFilters.selectItem(at: 0)
        }
        
        
        // Originally the name and size labels shouldn't show anything.
        imageNameLabel.stringValue = ""
        imageSizeLabel.stringValue = ""
    }
    
    
    
    // MARK: - Custom Methods
    
    /**
     It creates a CIFilter using the displayed image and produces a new image.
     
     The CIFilter to create is specified in the `appliedImageFilter` of the `imageEditorViewModel` object.
     This method is using the `createFilter(forImageWithData:additionalParameters:)` method of the
     `ImageFilter` enum to create the actual filter. If creating it fails, then the original image is
     set to the image view. On success it calls the `showFiltered(image:)` to display the new image
     after applying the filter effect.
     
     - Parameter params: A dictionary that contains the parameter names and values for filters that require
     parameters to be set. It can be nil, which means that no parameters are required by the filter, or the
     default values shoule be used.
     
    */
    func applyFilter(usingParameters params: [String: Any]?) {
        guard let originalImageData = imageEditorViewModel.originalImageData else { return }
        guard let filter = imageEditorViewModel.appliedImageFilter.createFilter(forImageWithData: originalImageData, additionalParameters: params) else {
            imageView.image = NSImage(data: originalImageData)
            return
        }
        
        showFiltered(image: filter.outputImage)
    }
    
    
    
    /**
     It gets the a CIImage, it converts it to a NSImage and it assigns it to the image view.
     
     The input image is a CIImage as created after applying the selected filter. The process shown
     in code is necessary to create a NSImage out of the given CIImage.
     
     Once the NSImage is created and assigned to the image view, the displayed image object is also
     updated in the `imageEditorViewModel` object through the `updateDisplayedImage(withImageData:)`.
     
     - Parameter image: The CIImage produced by the applied CIFilter to the displayed image.
    */
    func showFiltered(image: CIImage?) {
        guard let image = image else { return }
        let renderedImage = NSCIImageRep(ciImage: image)
        let displayImage = NSImage()
        displayImage.addRepresentation(renderedImage)
        imageView.image = displayImage
        
        // Convert the NSImage object to a data object using the tiffRepresentation
        // and update the displayed image object in the imageEditorViewModel object.
        guard let imageData = displayImage.tiffRepresentation else { return }
        imageEditorViewModel.updateDisplayedImage(withImageData: imageData)
        imageSizeLabel.stringValue = imageEditorViewModel.displayedImageSizeString
    }
    
    
    
    /**
     It initiates the resizing process of the displayed image using the given new size.
     
     Resizing is being initiated in the `resize(toSize:)` method of the `imageEditorViewModel`
     object.
     
     Note that along with the image view that is updated after the resize if finished, the
     `imageSizeLabel` is updated with the new size too.
     
     - Parameter newSize: The new size to resize to as it's taken from the `ResizeViewController`.
     
    */
    func resize(toSize newSize: CGSize) {
        imageEditorViewModel.resize(toSize: newSize) { [unowned self] in
            DispatchQueue.main.async { [unowned self] in
                guard let imageData = self.imageEditorViewModel.displayedImageData else { return }
                self.imageView.image = NSImage(data: imageData)
                self.imageSizeLabel.stringValue = self.imageEditorViewModel.displayedImageSizeString
            }
        }
    }
    
    
    
    
    // MARK: - IBAction Methods
    
    @IBAction func openImage(_ sender: Any) {
        
    }
    
    
    
    @IBAction func saveImage(_ sender: Any) {
        
    }
    
    
    @IBAction func clearImage(_ sender: Any) {
        imageEditorViewModel.clearImage()
        imageView.image = nil
        imageNameLabel.stringValue = ""
        imageSizeLabel.stringValue = ""
        colorFilters.selectItem(at: 0)
    }
    
    
    
    
    @IBAction func selectImageFilter(_ sender: Any) {
        
    }
    
    
    
    @IBAction func resizeImage(_ sender: Any) {
        
    }
    
    
}
